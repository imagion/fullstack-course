import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Buttons.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { useStatisticsControls } from "/src/store.js?t=1794132181984";
var _jsxFileName = "/mnt/shared/Projects/openstack/state-management/src/components/Buttons.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4128b04e";
var _s = $RefreshSig$();
const Buttons = () => {
	_s();
	const { addGood, addBad, addNeutral } = useStatisticsControls();
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("h2", { children: "give feedback" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 8,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("button", {
			onClick: addGood,
			children: "good"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("button", {
			onClick: addNeutral,
			children: "neutral"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("button", {
			onClick: addBad,
			children: "bad"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 7,
		columnNumber: 5
	}, this);
};
_s(Buttons, "rjrR0o9h2HUQSXghBlcb7iJQFug=", false, function() {
	return [useStatisticsControls];
});
_c = Buttons;
export default Buttons;
var _c;
$RefreshReg$(_c, "Buttons");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Buttons.jsx?t=1794132181984";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/shared/Projects/openstack/state-management/src/components/Buttons.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/shared/Projects/openstack/state-management/src/components/Buttons.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/mnt/shared/Projects/openstack/state-management/src/components/Buttons.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyw2QkFBNkI7Ozs7QUFFdEMsTUFBTSxnQkFBZ0I7O0NBQ3BCLE1BQU0sRUFBRSxTQUFTLFFBQVEsZUFBZSxzQkFBc0I7Q0FFOUQsT0FDRSx3QkFBQyxPQUFEO0VBQ0Usd0JBQUMsTUFBRCxZQUFJLGdCQUFpQjs7Ozs7RUFDckIsd0JBQUMsVUFBRDtHQUFRLFNBQVM7YUFBUztFQUFZOzs7OztFQUN0Qyx3QkFBQyxVQUFEO0dBQVEsU0FBUzthQUFZO0VBQWU7Ozs7O0VBQzVDLHdCQUFDLFVBQUQ7R0FBUSxTQUFTO2FBQVE7RUFBVzs7Ozs7Q0FDakM7Ozs7O0FBRVQ7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJCdXR0b25zLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0aXN0aWNzQ29udHJvbHMgfSBmcm9tICcuLi9zdG9yZSc7XG5cbmNvbnN0IEJ1dHRvbnMgPSAoKSA9PiB7XG4gIGNvbnN0IHsgYWRkR29vZCwgYWRkQmFkLCBhZGROZXV0cmFsIH0gPSB1c2VTdGF0aXN0aWNzQ29udHJvbHMoKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8aDI+Z2l2ZSBmZWVkYmFjazwvaDI+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e2FkZEdvb2R9Pmdvb2Q8L2J1dHRvbj5cbiAgICAgIDxidXR0b24gb25DbGljaz17YWRkTmV1dHJhbH0+bmV1dHJhbDwvYnV0dG9uPlxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXthZGRCYWR9PmJhZDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgQnV0dG9ucztcbiJdfQ==