import { create } from "/node_modules/.vite/deps/zustand.js?v=4128b04e";
import { useShallow } from "/node_modules/.vite/deps/zustand_shallow.js?v=0db8a2e2";
const useStatisticsStore = create((set) => ({
	good: 0,
	bad: 0,
	neutral: 0,
	actions: {
		addGood: () => set((state) => ({ good: state.good + 1 })),
		addBad: () => set((state) => ({ bad: state.bad + 1 })),
		addNeutral: () => set((state) => ({ neutral: state.neutral + 1 }))
	}
}));
export const useStatistics = () => useStatisticsStore(useShallow((state) => ({
	good: state.good,
	bad: state.bad,
	neutral: state.neutral
})));
export const useStatisticsControls = () => useStatisticsStore((state) => state.actions);

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsa0JBQWtCO0FBRTNCLE1BQU0scUJBQXFCLFFBQVEsU0FBUztDQUMxQyxNQUFNO0NBQ04sS0FBSztDQUNMLFNBQVM7Q0FDVCxTQUFTO0VBQ1AsZUFBZSxLQUFLLFdBQVcsRUFBRSxNQUFNLE1BQU0sT0FBTyxFQUFFLEVBQUU7RUFDeEQsY0FBYyxLQUFLLFdBQVcsRUFBRSxLQUFLLE1BQU0sTUFBTSxFQUFFLEVBQUU7RUFDckQsa0JBQWtCLEtBQUssV0FBVyxFQUFFLFNBQVMsTUFBTSxVQUFVLEVBQUUsRUFBRTtDQUNuRTtBQUNGLEVBQUU7QUFFRixPQUFPLE1BQU0sc0JBQ1gsbUJBQ0UsWUFBWSxXQUFXO0NBQ3JCLE1BQU0sTUFBTTtDQUNaLEtBQUssTUFBTTtDQUNYLFNBQVMsTUFBTTtBQUNqQixFQUFFLENBQ0o7QUFFRixPQUFPLE1BQU0sOEJBQ1gsb0JBQW9CLFVBQVUsTUFBTSxPQUFPIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInN0b3JlLmpzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZSB9IGZyb20gJ3p1c3RhbmQnO1xuaW1wb3J0IHsgdXNlU2hhbGxvdyB9IGZyb20gJ3p1c3RhbmQvc2hhbGxvdyc7XG5cbmNvbnN0IHVzZVN0YXRpc3RpY3NTdG9yZSA9IGNyZWF0ZSgoc2V0KSA9PiAoe1xuICBnb29kOiAwLFxuICBiYWQ6IDAsXG4gIG5ldXRyYWw6IDAsXG4gIGFjdGlvbnM6IHtcbiAgICBhZGRHb29kOiAoKSA9PiBzZXQoKHN0YXRlKSA9PiAoeyBnb29kOiBzdGF0ZS5nb29kICsgMSB9KSksXG4gICAgYWRkQmFkOiAoKSA9PiBzZXQoKHN0YXRlKSA9PiAoeyBiYWQ6IHN0YXRlLmJhZCArIDEgfSkpLFxuICAgIGFkZE5ldXRyYWw6ICgpID0+IHNldCgoc3RhdGUpID0+ICh7IG5ldXRyYWw6IHN0YXRlLm5ldXRyYWwgKyAxIH0pKSxcbiAgfSxcbn0pKTtcblxuZXhwb3J0IGNvbnN0IHVzZVN0YXRpc3RpY3MgPSAoKSA9PlxuICB1c2VTdGF0aXN0aWNzU3RvcmUoXG4gICAgdXNlU2hhbGxvdygoc3RhdGUpID0+ICh7XG4gICAgICBnb29kOiBzdGF0ZS5nb29kLFxuICAgICAgYmFkOiBzdGF0ZS5iYWQsXG4gICAgICBuZXV0cmFsOiBzdGF0ZS5uZXV0cmFsLFxuICAgIH0pKSxcbiAgKTtcblxuZXhwb3J0IGNvbnN0IHVzZVN0YXRpc3RpY3NDb250cm9scyA9ICgpID0+XG4gIHVzZVN0YXRpc3RpY3NTdG9yZSgoc3RhdGUpID0+IHN0YXRlLmFjdGlvbnMpO1xuIl19