import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Statistics.jsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { useStatistics } from "/src/store.js?t=1794132181984";
var _jsxFileName = "/mnt/shared/Projects/openstack/state-management/src/components/Statistics.jsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4128b04e";
var _s = $RefreshSig$();
const Statistics = () => {
	_s();
	const { good, bad, neutral } = useStatistics();
	const all = good + bad + neutral;
	let average = (good - bad) / all;
	let positive = good / all * 100;
	if (all === 0) {
		average = 0;
		positive = 0;
	}
	return /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", { children: "statistics" }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 7
	}, this), /* @__PURE__ */ _jsxDEV("table", { children: /* @__PURE__ */ _jsxDEV("tbody", { children: [
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "good" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: good }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 13
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "neutral" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: neutral }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 13
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "bad" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: bad }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 30,
			columnNumber: 13
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "all" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: all }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 34,
			columnNumber: 13
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 32,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "average" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: average }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 13
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 36,
			columnNumber: 11
		}, this),
		/* @__PURE__ */ _jsxDEV("tr", { children: [/* @__PURE__ */ _jsxDEV("td", { children: "positive" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 41,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("td", { children: [positive, " %"] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 13
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 11
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 9
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 5
	}, this);
};
_s(Statistics, "x+azy1ZUbuHYvP1tV9CuCytM3qo=", false, function() {
	return [useStatistics];
});
_c = Statistics;
export default Statistics;
var _c;
$RefreshReg$(_c, "Statistics");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Statistics.jsx?t=1794135170580";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/mnt/shared/Projects/openstack/state-management/src/components/Statistics.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/mnt/shared/Projects/openstack/state-management/src/components/Statistics.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/mnt/shared/Projects/openstack/state-management/src/components/Statistics.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxxQkFBcUI7Ozs7QUFFOUIsTUFBTSxtQkFBbUI7O0NBQ3ZCLE1BQU0sRUFBRSxNQUFNLEtBQUssWUFBWSxjQUFjO0NBRTdDLE1BQU0sTUFBTSxPQUFPLE1BQU07Q0FDekIsSUFBSSxXQUFXLE9BQU8sT0FBTztDQUM3QixJQUFJLFdBQVksT0FBTyxNQUFPO0NBRTlCLElBQUksUUFBUSxHQUFHO0VBQ2IsVUFBVTtFQUNWLFdBQVc7Q0FDYjtDQUVBLE9BQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQsWUFBSSxhQUFjOzs7O1dBQ2xCLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxTQUFEO0VBQ0Usd0JBQUMsTUFBRCxhQUNFLHdCQUFDLE1BQUQsWUFBSSxPQUFROzs7O1lBQ1osd0JBQUMsTUFBRCxZQUFLLEtBQVM7Ozs7VUFDWjs7Ozs7RUFDSix3QkFBQyxNQUFELGFBQ0Usd0JBQUMsTUFBRCxZQUFJLFVBQVc7Ozs7WUFDZix3QkFBQyxNQUFELFlBQUssUUFBWTs7OztVQUNmOzs7OztFQUNKLHdCQUFDLE1BQUQsYUFDRSx3QkFBQyxNQUFELFlBQUksTUFBTzs7OztZQUNYLHdCQUFDLE1BQUQsWUFBSyxJQUFROzs7O1VBQ1g7Ozs7O0VBQ0osd0JBQUMsTUFBRCxhQUNFLHdCQUFDLE1BQUQsWUFBSSxNQUFPOzs7O1lBQ1gsd0JBQUMsTUFBRCxZQUFLLElBQVE7Ozs7VUFDWDs7Ozs7RUFDSix3QkFBQyxNQUFELGFBQ0Usd0JBQUMsTUFBRCxZQUFJLFVBQVc7Ozs7WUFDZix3QkFBQyxNQUFELFlBQUssUUFBWTs7OztVQUNmOzs7OztFQUNKLHdCQUFDLE1BQUQsYUFDRSx3QkFBQyxNQUFELFlBQUksV0FBWTs7OztZQUNoQix3QkFBQyxNQUFELGFBQUssVUFBUyxJQUFNOzs7O1VBQ2xCOzs7OztDQUNDOzs7O1VBQ0Y7Ozs7U0FDSjs7Ozs7QUFFVDs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlN0YXRpc3RpY3MuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRpc3RpY3MgfSBmcm9tICcuLi9zdG9yZSc7XG5cbmNvbnN0IFN0YXRpc3RpY3MgPSAoKSA9PiB7XG4gIGNvbnN0IHsgZ29vZCwgYmFkLCBuZXV0cmFsIH0gPSB1c2VTdGF0aXN0aWNzKCk7XG5cbiAgY29uc3QgYWxsID0gZ29vZCArIGJhZCArIG5ldXRyYWw7XG4gIGxldCBhdmVyYWdlID0gKGdvb2QgLSBiYWQpIC8gYWxsO1xuICBsZXQgcG9zaXRpdmUgPSAoZ29vZCAvIGFsbCkgKiAxMDA7XG5cbiAgaWYgKGFsbCA9PT0gMCkge1xuICAgIGF2ZXJhZ2UgPSAwO1xuICAgIHBvc2l0aXZlID0gMDtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxoMj5zdGF0aXN0aWNzPC9oMj5cbiAgICAgIDx0YWJsZT5cbiAgICAgICAgPHRib2R5PlxuICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgIDx0ZD5nb29kPC90ZD5cbiAgICAgICAgICAgIDx0ZD57Z29vZH08L3RkPlxuICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgPHRyPlxuICAgICAgICAgICAgPHRkPm5ldXRyYWw8L3RkPlxuICAgICAgICAgICAgPHRkPntuZXV0cmFsfTwvdGQ+XG4gICAgICAgICAgPC90cj5cbiAgICAgICAgICA8dHI+XG4gICAgICAgICAgICA8dGQ+YmFkPC90ZD5cbiAgICAgICAgICAgIDx0ZD57YmFkfTwvdGQ+XG4gICAgICAgICAgPC90cj5cbiAgICAgICAgICA8dHI+XG4gICAgICAgICAgICA8dGQ+YWxsPC90ZD5cbiAgICAgICAgICAgIDx0ZD57YWxsfTwvdGQ+XG4gICAgICAgICAgPC90cj5cbiAgICAgICAgICA8dHI+XG4gICAgICAgICAgICA8dGQ+YXZlcmFnZTwvdGQ+XG4gICAgICAgICAgICA8dGQ+e2F2ZXJhZ2V9PC90ZD5cbiAgICAgICAgICA8L3RyPlxuICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgIDx0ZD5wb3NpdGl2ZTwvdGQ+XG4gICAgICAgICAgICA8dGQ+e3Bvc2l0aXZlfSAlPC90ZD5cbiAgICAgICAgICA8L3RyPlxuICAgICAgICA8L3Rib2R5PlxuICAgICAgPC90YWJsZT5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFN0YXRpc3RpY3M7XG4iXX0=